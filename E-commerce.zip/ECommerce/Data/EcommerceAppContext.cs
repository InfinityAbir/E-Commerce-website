﻿using Ecommerce.Models;
using Microsoft.EntityFrameworkCore;

#region DbContext
namespace Ecommerce.Data
{
    public class EcommerceAppContext : DbContext
    {
        public EcommerceAppContext(DbContextOptions<EcommerceAppContext> options) : base(options) { }

        public DbSet<Admin> Admins { get; set; }
        public DbSet<Cart> Carts { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Inventory> Inventories { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Rating> Ratings { get; set; }
        public DbSet<Wishlist> Wishlists { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Admin>().HasIndex(a => a.Email).IsUnique();
            modelBuilder.Entity<Admin>().HasIndex(p => p.Phone).IsUnique();
            modelBuilder.Entity<Customer>().HasIndex(c=> c.PhoneNumber).IsUnique();
            modelBuilder.Entity<Customer>().HasIndex(e => e.Email).IsUnique();
            modelBuilder.Entity<Payment>().HasIndex(d => d.Id).IsUnique();

            /*modelBuilder.Entity<Cart>().ToTable("Carts");
            modelBuilder.Entity<Category>().ToTable("Categories");
            modelBuilder.Entity<Customer>().ToTable("Customers");
            modelBuilder.Entity<Inventory>().ToTable("Inventories");
            modelBuilder.Entity<Order>().ToTable("Orders");
            modelBuilder.Entity<Payment>().ToTable("Payments");
            modelBuilder.Entity<Product>().ToTable("Products");
            modelBuilder.Entity<Rating>().ToTable("Ratings");
            modelBuilder.Entity<Wishlist>().ToTable("Wishlists");
            base.OnModelCreating(modelBuilder);*/
        }
    }

}
#endregion