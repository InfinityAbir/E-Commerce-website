﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Ecommerce.Models
{
    public class Order
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int OrderId { get; set; }
        public DateTime OrderDate { get; set; }
        [Required]
        [Range(0.01, double.MaxValue, ErrorMessage = "Total price must be a positive number.")]
        public decimal TotalAmount { get; set; }
        [Required]
        public string Status { get; set; } // e.g., "Pending", "Shipped", "Delivered"
        public DateTime CreatedAt { get; set; }
        [ForeignKey("Customer")]
        public int CustomerId { get; set; }
        public virtual Customer Customer { get; set; } 
        public int Rating { get; internal set; }
        public string? Comment { get; internal set; }
    }
}
