﻿using System.ComponentModel.DataAnnotations;

namespace Ecommerce.Models
{
    public class Payment
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string PaymentMethod { get; set; }
        [Required]
        [Range(0.01, double.MaxValue, ErrorMessage = "Amount must be a positive number.")]
        public decimal Amount { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public Payment()
        {
            CreatedAt = DateTime.Now;
            UpdatedAt = DateTime.Now;
        }
    }
}
